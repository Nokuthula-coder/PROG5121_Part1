/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.regloginsystem;
//these lines are for importing the required classes in the program
import java.util.Scanner; //this let us read the input from the keyboard
import java.util.ArrayList; //this allows us to store users data
import java.util.regex.Pattern;//this enables us to check patterns like password and cell phone number
/**
 *this is the main class where all the logic and method are written
 * @author RC_Student_Lab
 */
public class Regloginsystem {
    //Scanner is used to read user input from the keyboard
static Scanner scanner= new Scanner (System.in);
    //this list will store all registered user
static ArrayList<User>users=new ArrayList<>();
    //this will store the login status message to show after the user login
static String loginStatusMessage="";
//this is the first method that will execute when the program starts   
    public static void main(String[] args) {
         // Call the registerUser method and save its return message
       String regResult = registerUser();
       // Print the registration message
       System.out.println(regResult);
       // Call the loginUser method to log in the user
       boolean loggedIn = loginUser();
       // Show the login result using the returnLoginStatus method
       System.out.println(returnLoginStatus(loggedIn));
       
   }
    //this inner class stores user information like name, phone number and password
    static class User{
        String firstName;
        String lastName;
        String phoneNumber;
        String username;
        String password;
        //constructor to save user information when a new user is created
        User(String firstName,String lastName,String phoneNumber,String username,String password){
            this.firstName = firstName;
            this.lastName = lastName;
            this.phoneNumber = phoneNumber;
            this.username = username;
            this.password = password;
        }
    }
    //this method checks if the username has an underscore and is 5 characters or less
    public static boolean checkUserName(String username) {
            if (username.contains("_")) {
                if(username.length()<=5) {
                    return true;   
                }else{
                    return false;
                }
                }else{
                    return false;
        }
    }
    //this method checks if the password is strong using a pattern (regex)
    public static boolean checkPasswordComplexity(String password) {
        //password must have a capital letter,number,special character and be 8+ characters long
        String pattern = "^(?=.*[A-Z])(?=.*\\d)(?=.*[!@#$%^&*()_+=\\-{}\\[\\]:;\"'<>,.?/~`|]).{8,}$";
        boolean matches = Pattern.matches(pattern, password);
        return matches;
    }
   //this method checks if the phone number starts with +27 and has exactly 9 digits afterwards
    public static boolean checkCellPhoneNumber(String phoneNumber) {
        String pattern = "^\\+27\\d{9}$";
        return Pattern.matches(pattern, phoneNumber);
    }
    //this method handles the registration process for a new user
    public static String registerUser() {
        System.out.println("--- User Registration ---");
        //ask for first name and save it
        System.out.print("Enter First Name: ");
        String firstName = scanner.nextLine();
        //ask for last name and save it
        System.out.print("Enter Last Name: ");
        String lastName = scanner.nextLine();
    //loop to keep asking until a vaild username is entered
    String username ="" ;
    boolean validUsername = false;
    while (validUsername == false) {
        System.out.print("Enter Username (Username must have underscore _ and maximum of 5 characters): ");
        username = scanner.nextLine();
        validUsername = checkUserName(username) ;

        if (validUsername == false){
            System.out.println("Username is not correctly formatted, please ensure that your username contains an underscore _ and is no more than 5 characters in length.");
        }else{
            System.out.println(" Username successfully captured.") ;
        }
    }
     //looop to keep asking until a valid password is entered
     String password = "";
     boolean validPassword = false;
     while (validPassword == false) {
         System.out.print("Enter Password: ");
         password = scanner.nextLine();
         validPassword = checkPasswordComplexity(password) ;
         
        if (validPassword== false) {
             System.out.println("Password is not correctly formatted, please ensure that the password contains atleast 8 characters, a capital letter, a number and a special character");
        }else{
             System.out.println("Password successfully captured.");
        }
    }
     //loop to keep asking until a valid phone number is entered
     String phoneNumber = "";
     boolean phoneOK = false;
     while (phoneOK == false){
         System.out.print("Enter Cell Phone (+27xxxxxxx): ");
         phoneNumber = scanner.nextLine();
         phoneOK = checkCellPhoneNumber(phoneNumber) ;
         
         if (phoneOK == false){
             System.out.println("Cell number is incorrectly formatted or does not contain an international code, please correct the number and try again");
        }else{
             System.out.println("Cell number successfully captured");
        }
    }
    // save the new user in the users list
    users.add(new User(firstName, lastName, phoneNumber, username, password));
    // Return message after registration
    return "Registration complete!";
   }
    // This method handles the login process
    public static boolean loginUser() {
    System.out.println("User Login");
     // Ask the user for their username
     System.out.print("Enter Username: ");
        String usernameInput = scanner.nextLine();
    // Loop through the list of users to find a match
        for (int i = 0; i < users.size(); i++) {
            User currentUser = users.get(i);
        // Check if username matches
            if (currentUser.username.equals(usernameInput)) {
            boolean passwordCorrect = false;
            // Keep asking for password until the correct one is entered
                while (!passwordCorrect) {
                    System.out.print("Enter Password: ");
                    String passwordInput = scanner.nextLine();
                 // If the password matches, set the message and return true
                    if (currentUser.password.equals(passwordInput)) {
                       loginStatusMessage = "Welcome " + currentUser.firstName + ", " + currentUser.lastName + " it is great to see you again.";
                       return true;
                    }else{
                       // If password is wrong, try again
                       System.out.println("Password incorrect. Please try again.");
                    }
                }
            }
        }
        // If username was not found
       loginStatusMessage = "Username not found. Please register first.";
       return false;
    }
    // This method returns the login status message stored earlier
    public static String returnLoginStatus(boolean status) {
       return loginStatusMessage;
    }
}